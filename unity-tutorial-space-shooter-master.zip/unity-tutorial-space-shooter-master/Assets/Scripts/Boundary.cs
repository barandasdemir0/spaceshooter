﻿using System;

[System.Serializable]
public class Boundary
{
	public float xMin, xMax, zMin, zMax;
}

